from django.apps import AppConfig


class AppValorantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_valorant'
