from django.contrib import admin
from app_valorant.models import User, Contacto, mapas, Creadores



# Register your models here.

admin.site.register(User)
admin.site.register(Contacto)
admin.site.register(mapas)
admin.site.register(Creadores)